async function loadBooks() {
  // TODO 13: fetch("/books") and convert to JSON
  // TODO 14: render books into #book-list
}

window.addEventListener("DOMContentLoaded", loadBooks);
